<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mapa_controller extends CI_Controller {

	// Show filter page
	public function index()
	{
		$this->load->view('filter');
	}

}
?>