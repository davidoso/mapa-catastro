<?php

class Mapa_model extends CI_Model {

	public function getUser($data)
	{
		$this->db->where('username', $data['username']);
		$this->db->where('password', $data['password']);
		$query = $this->db->get('dbo.tbl_users');

		return $query->row_array();
	}

	public function createUser($data)
	{
		$this->db->where('username', $data['username']);
		$query = $this->db->get('dbo.tbl_users')->result_array();

		if(empty($query)) {
			$this->db->insert('dbo.tbl_users', $data);
		}

		return $this->db->affected_rows();
	}

}
?>