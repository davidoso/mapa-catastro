<?php
    function switchColumn($column, $value) {
        switch($column) {
            case "NOMBRE":
                return "nombre like '%" . $value . "%'";
                break;
            case "SERVICIO": // Normal bank or ATM
            case "TIPO": // Phone type
                return "tipo = '" . $value . "'";
                break;
            case "EMPRESA":
                return "empresa_responsable = '" . $value . "'";
                break;
            case "MATERIAL":
                switch($value) {
                    case "CONCRETO":
                        return "id_material = 3";
                        break;
                    case "MADERA":
                        return "id_material = 22";
                        break;
                    case "METAL":
                        return "id_material = 23";
                        break;
                    case "ACERO":
                        return "id_material = 24";
                        break;
                    case "AZULEJO":
                        return "id_material = 12";
                        break;
                    case "CEMENTO":
                        return "id_material = 13";
                        break;
                    case "FIERRO":
                        return "id_material = 14";
                        break;
                    case "GRANITO":
                        return "id_material = 15";
                        break;
                    case "LADRILLO":
                        return "id_material = 16";
                        break;
                    case "MÁRMOL":
                        return "id_material = 17";
                        break;
                    case "MARMOLINA":
                        return "id_material = 18";
                        break;
                    case "PIEDRA":
                        return "id_material = 20";
                        break;
                    case "TIERRA":
                        return "id_material = 21";
                        break;
                }
                break;
            case "CONDICIÓN FÍSICA":
                switch($value) {
                    case "BUENA":
                        return "id_cond_fisica = 1";
                        break;
                    case "REGULAR":
                        return "id_cond_fisica = 2";
                        break;
                    case "MALA":
                        return "id_cond_fisica = 3";
                        break;
                    case "DESCONOCIDA":
                        return "id_cond_fisica = 4";
                        break;
                    case "EN RUINAS":
                        return "id_cond_fisica = 8";
                        break;
                }
                break;
            case "FUNCIONA":
                return "funciona = '" . $value . "'";
                break;
            case "FUENTE":
                if ($value === "SIN FUENTE") {
                    return "f_secundaria IS NULL";
                }
                else {
                    return "f_secundaria = '" . $value . "'";
                }
                break;
            case "ÉPOCA":
                return "epoca = '" . $value . "'";
                break;
            case "GÉNERO ARQUITECTÓNICO":
                return "genero_arquitectonico = '" . $value . "'";
                break;
            default: //"(SIN FILTROS)" shows all the data from the specified SQL table
                return "1 = 1";
                break;
        }
    }

    function pointsArrayToString($pointsArray) {
        $polygonCoordinates = "";
        for ($i = 0; $i < count($pointsArray); $i++) {
            if (($i + 1) % 2 == 0) {
                $polygonCoordinates = $polygonCoordinates . $pointsArray[$i] . ', ';
            }
            else {
                $polygonCoordinates = $polygonCoordinates . $pointsArray[$i] . ' ';
            }
        }
        return substr($polygonCoordinates, 0, -2); // Drop last comma and whitespace
    }

    // Unescape the string values in the JSON arrays
    $tableData = stripcslashes($_POST['pTableData']);           // 3-column table filters (layer, field and value)
    $booleanOp = stripcslashes($_POST['pBooleanOp']);           // OR or AND operator to join WHERE clauses
    $pointsArray = stripcslashes($_POST['pPointsArray']);       // Polygon coordinates in the map

    // Decode the JSON arrays
    $tableData = json_decode($tableData, TRUE);
    $booleanOp = json_decode($booleanOp, TRUE);
    $pointsArray = json_decode($pointsArray, TRUE);

?>