<?php
    function switchTable($layer) {
        $cond_fisica =
            "JOIN ct_cond_fisica CF on T.id_cond_fisica = CF.id_cond_fisica";
        $cond_fisica_and_material =
            "JOIN ct_cond_fisica CF on T.id_cond_fisica = CF.id_cond_fisica
            JOIN ct_material CM on T.id_material = CM.id_material";

        switch($layer) {
            case "BANCOS":
                return "FROM generales.tbl_bancos";
                break;
            case "HOTELES":
                return "FROM generales.tbl_hoteles";
                break;
            case "POSTES":
                return "FROM generales.tbl_postes T " . $cond_fisica_and_material;
                break;
            case "TELEFONOS":
                return "FROM generales.tbl_telefonos_publicos T " . $cond_fisica;
                break;
            case "MONUMENTOS":
                return "FROM inah.tbl_monumentos_historicos";
                break;
            case "PANTEON":
                return "FROM registro_civil.tbl_panteon_municipal T " . $cond_fisica_and_material;
                break;
            case "LUMINARIAS":
                return "FROM servicios_publicos.tbl_luminarias T " . $cond_fisica_and_material;
                break;
        }
    }

    function switchColumn($layer) {
        $coordinates =
            "coord_y AS 'LATITUD', coord_x AS 'LONGITUD', "; // Latitude appears first on GPS coordinates
        $cond_fisica =
            "CF.cond_fisica AS 'CONDICIÓN FÍSICA'";
        $cond_fisica_and_material =
            "CM.material AS 'MATERIAL', CF.cond_fisica AS 'CONDICIÓN FÍSICA'";

        switch($layer) {
            case "BANCOS":
                return $coordinates . "NOMBRE AS 'BANCO', TIPO AS 'SERVICIO'";
                break;
            case "HOTELES":
                return $coordinates . "NOMBRE AS 'HOTEL'";
                break;
            case "POSTES":
                return $coordinates . "empresa_responsable AS 'EMPRESA', " . $cond_fisica_and_material;
                break;
            case "TELEFONOS":
                return $coordinates . "empresa_responsable AS 'EMPRESA', tipo AS 'TIPO', funciona AS 'FUNCIONA (SI/NO)', " . $cond_fisica;
                break;
            case "MONUMENTOS":
                return $coordinates . "epoca AS 'ÉPOCA', genero_arquitectonico AS 'GÉNERO ARQUITECTÓNICO'";
                break;
            case "PANTEON":
                return $coordinates . "capacidad AS 'CAPACIDAD', " . $cond_fisica_and_material;
                break;
            case "LUMINARIAS":
                return $coordinates . "f_secundaria AS 'FUENTE (SECUNDARIA)', " . $cond_fisica_and_material;
                break;
        }
    }

?>