<?php
    function switchTable($layer) {
        switch($layer) {
            case "BANCOS":
                return "generales.tbl_bancos";
                break;
            case "HOTELES":
                return "generales.tbl_hoteles";
                break;
            case "POSTES":
                return "generales.tbl_postes";
                break;
            case "TELEFONOS":
                return "generales.tbl_telefonos_publicos";
                break;
            case "MONUMENTOS":
                return "inah.tbl_monumentos_historicos";
                break;
            case "PANTEON":
                return "registro_civil.tbl_panteon_municipal";
                break;
            case "LUMINARIAS":
                return "servicios_publicos.tbl_luminarias";
                break;
        }
    }

?>