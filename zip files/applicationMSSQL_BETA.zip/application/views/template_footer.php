<div id="myfooterwrap">
	<div class="container">
		<div class="row">
			<p>Copyright © H. Ayuntamiento de Colima</p>
		</div>
	</div>
</div>