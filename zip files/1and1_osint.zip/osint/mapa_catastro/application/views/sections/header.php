<div id="myheaderwrap">
	<div class="container">
		<div class="col-sm-3">
			<a href="http://www.catastrocolima.gob.mx/cartografia.html" title="Ir al mapa cartográfico digital" target="_blank"><b>MAPA CARTOGRÁFICO</b></a>
		</div>
		<div class="col-sm-9">
			<h3 style="color: #FAFAFA; margin-top: -5px;">FILTROS DE BÚSQUEDA EN COLIMA, COL.</h3>
		</div>
	</div> <!-- container -->
</div> <!-- navbar-inverse -->