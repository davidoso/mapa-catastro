<title>CATASTRO | MAPA</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<base href="<?php echo base_url();?>">
<!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/favicons/map.ico"/>
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/icomoon.css">
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/my-styles.css">
<!--===============================================================================================-->