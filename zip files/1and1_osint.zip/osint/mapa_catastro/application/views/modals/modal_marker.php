<div class="modal fade" id="myModalMapMarker" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">

			<div class="modal-body">
                <center>
					<!-- This is neither table nor table-bordered class -->
                    <table id="tblMarkerInfo" style="margin: 0px; width: 100%">
                    </table>
                </center>
				<br>
				<center>
					<a id="aGoogleMaps" class="text-danger" href="#" target="_blank">Ver en Google Maps&nbsp;
    				<i class="fa fa-map-marker" aria-hidden="true"></i></a>
				</center>
			</div> <!-- modal-body -->
		</div> <!-- modal-content -->
	</div> <!-- modal-dialog -->
</div> <!-- modal fade -->