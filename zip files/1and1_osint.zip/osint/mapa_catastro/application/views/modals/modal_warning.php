<div class="modal fade" id="myModalMapWarnings" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">

			<div class="modal-header" style="background-color: #eee;" align="center">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">
					<img src="images/warning1.png" id="logo-alertaModal" style="height: 60px; width: 60px;">
				</h4>
				<h3 id="h3ModalMapWarning" align="center" class="text-secondary"></h3>
			</div> <!-- modal-header -->

			<div class="modal-body">
				<form class="form-horizontal">
					<div class="form-group">
						<center>
							<div class="col-sm-offset-1 col-sm-10">
								<strong id="messageModalMapWarning" class="text-info">
								</strong>
							</div>
						</center>
					</div>
				</form>
			</div> <!-- modal-body -->
		</div> <!-- modal-content -->
	</div> <!-- modal-dialog -->
</div> <!-- modal fade -->